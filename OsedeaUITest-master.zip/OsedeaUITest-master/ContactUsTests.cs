﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OsedeaGUITest.SeleniumHelpers;
using OsedeaGUITest.Utilities;
using OsedeaGUITest.PageObjects;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace OsedeaGUITest
{
    [TestFixture]
    public class ContactUsTests
    {
        private IWebDriver _driver;
        private string _baseUrl;
        private SeleniumUtils seleniumUtils;

        [SetUp]
        public void Setup()
        {
            _driver = new DriverFactory().CreateDriver();
            _baseUrl = ConfigurationHelper.Get<string>("TargetUrl");
            seleniumUtils = new SeleniumUtils(_driver);
        }

        [TearDown]
        public void Teardown()
        {
            try
            {
                //Close the browser
                _driver.Quit();
                _driver.Close();
            }
            catch (Exception)
            {
                // Log if there are any errors either in table or console
            }
        }

        [Test]
        public void ContactUsWrongEmailFailureTest()
        {
            var homePage = new HomePage(_driver);

            var culturePage = homePage.NavigateToCulturePage(_baseUrl);

            var contactUs = culturePage.ClickContactUsFooter();

            contactUs.PopulateContactUs("Johnny","Doe","testSubject","wrongemail.com","5142222222","testscript" );

            //Look for the error message. If not present the fail
            //This could also be part of pageobject based on requirement
            if (seleniumUtils.IsElementPresent(By.XPath("//*[@id='content']/main/div/form/div/div[4]/p")))
            {
                var errMsg = _driver.FindElement(By.XPath("//*[@id='content']/main/div/form/div/div[4]/p")).Text;
                Assert.AreEqual("Please enter a valid email.", errMsg);
            }
            else
            {
                Assert.Fail();
            }
        }

        [Test]
        public void ContactUsSubmissionTest()
        {
            var homePage = new HomePage(_driver);

            var culturePage = homePage.NavigateToCulturePage(_baseUrl);

            var contactUs = culturePage.ClickContactUsFooter();

            contactUs.PopulateContactUs("Johnny", "Doe", "testSubject", "test@gmail.com", "5142222222", "testscript");

            contactUs.btnSend.Click();

            //Explicitly look for the message, ignore no element exception untill the timeout. If not present then fail. This is using common functionality.            
            var element = WebDriverExtensions.FindElement(_driver, By.XPath("//*[@id='content']/main/div/form/div/div/h3"), 10);

            Assert.AreEqual("Your message is on its way!", element.Text);
        }
    }
}
