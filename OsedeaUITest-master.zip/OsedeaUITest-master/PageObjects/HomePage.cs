﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support;
using SeleniumExtras.PageObjects;
using OsedeaGUITest.PageObjects;
using OpenQA.Selenium.Interactions;

namespace OsedeaGUITest.PageObjects
{
    public class HomePage
    {
        private readonly IWebDriver _driver;

        public HomePage(IWebDriver driver)
        {
            _driver = driver;
            PageFactory.InitElements(_driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//*[@id=\"content\"]/section[1]/div[2]/a/button")]
        public IWebElement btnContactUs { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='gatsby-focus-wrapper']/div/footer/section/div[1]/div[1]/a/button")]
        public IWebElement btnContactUsFooter { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='gatsby-focus-wrapper']/div/div[3]/div/div[2]/button")]
        public IWebElement btnContactUsCookieAccept { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='content']/div[2]/div/div[2]/span/a")]
        public IWebElement btnExploreCulture { get; set; }

        /// <summary>
        /// This function allows us to navigate to the culture page and returns the culture page
        /// </summary>
        /// <param name="baseUrl"></param>
        /// <returns></returns>
        public CulturePage NavigateToCulturePage(string baseUrl)
        {
            _driver.Navigate().GoToUrl(baseUrl);

            if (btnContactUsCookieAccept.Displayed)
            {
                btnContactUsCookieAccept.Click();
            }

            btnExploreCulture.Click();

            return new CulturePage(_driver);
        }
    }
}
