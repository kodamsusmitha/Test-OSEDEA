﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using SeleniumExtras.PageObjects;
using System;

namespace OsedeaGUITest.PageObjects
{
    public class CulturePage
    {
        private readonly IWebDriver _driver;

        public CulturePage(IWebDriver driver)
        {
            _driver = driver;
            PageFactory.InitElements(_driver, this);
        }
                
        [FindsBy(How = How.XPath, Using = "//*[@id='gatsby-focus-wrapper']/div/footer/section/div[1]/div[1]/a")]
        public IWebElement btnContactUsFooter { get; set; }

        /// <summary>
        /// This function clicks on the contact us button on the footer, It does that by scrolling to the footer and then clicking on the button
        /// Returns the Contact page
        /// </summary>
        /// <returns></returns>
        public ContactPage ClickContactUsFooter()
        {

            // Scroll to specific location
            Actions actions = new Actions(_driver);
            actions.MoveToElement(btnContactUsFooter);
            actions.Perform();

            btnContactUsFooter.Click();
            return new ContactPage(_driver);
        }
    }
}
