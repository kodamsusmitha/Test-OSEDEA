﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;

namespace OsedeaGUITest.PageObjects
{
    public class ContactPage
    {
        private readonly IWebDriver _driver;
        public ContactPage(IWebDriver driver)
        {
            _driver = driver;
            PageFactory.InitElements(_driver, this);
        }

        [FindsBy(How = How.Id, Using = "firstName")]
        public IWebElement txtFirstName { get; set; }

        [FindsBy(How = How.Id, Using = "lastName")]
        public IWebElement txtLastName { get; set; }

        [FindsBy(How = How.Id, Using = "subject")]
        public IWebElement txtSubject { get; set; }

        [FindsBy(How = How.Id, Using = "human_email")]
        public IWebElement txtEmail{ get; set; }

        [FindsBy(How = How.Id, Using = "phone")]
        public IWebElement txtPhone { get; set; }

        [FindsBy(How = How.Id, Using = "note")]
        public IWebElement txtNote { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='content']/main/div/form/div/div[8]/button")]
        public IWebElement btnSend { get; set; }

        

        public void PopulateContactUs(string firstName = "John", string lastName = "Doe", string subject = "test Subject", string email = "susmitha@gmail.com", string phone = "5142221111", string note = "this is a test script")
        {
            try
            {
                //Fill the contactus form
                txtFirstName.SendKeys(firstName);
                txtLastName.SendKeys(lastName);
                txtSubject.SendKeys(subject);
                txtEmail.SendKeys(email);
                txtPhone.SendKeys(phone);
                txtNote.SendKeys(note);
            }
            catch (Exception)
            {
                // Log any errors that occur here to log files or log tables 
                throw;
            }
        }
        

    }
}
