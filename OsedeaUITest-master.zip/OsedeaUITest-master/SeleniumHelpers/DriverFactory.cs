﻿using System;
using System.Configuration;
using System.Diagnostics;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Remote;
using OsedeaGUITest.Utilities;

namespace OsedeaGUITest.SeleniumHelpers
{
    public enum Driver
    {
        InternetExplorer,
        Edge,
        Chrome,
        Firefox
    }
    public class DriverFactory
    {

        public IWebDriver CreateDriver()
        {
            IWebDriver driver;
            var driverToUse = ConfigurationHelper.Get<Driver>("DriverToUse");

            switch (driverToUse)
            {
                case Driver.InternetExplorer:
                    driver = new InternetExplorerDriver(AppDomain.CurrentDomain.BaseDirectory, new InternetExplorerOptions(), TimeSpan.FromMinutes(5));
                    break;
                case Driver.Edge:
                    driver = new EdgeDriver();
                    break;
                case Driver.Firefox:
                    driver = new FirefoxDriver();
                    break;
                case Driver.Chrome:
                    driver = new ChromeDriver();
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }

            driver.Manage().Window.Maximize();
            var timeouts = driver.Manage().Timeouts();

            //timeouts.ImplicitWait = TimeSpan.FromSeconds(ConfigurationHelper.Get<int>("ImplicitlyWait"));
            //timeouts.PageLoad = TimeSpan.FromSeconds(ConfigurationHelper.Get<int>("PageLoadTimeout"));

            timeouts.ImplicitWait = TimeSpan.FromSeconds(30);
            timeouts.PageLoad = TimeSpan.FromSeconds(60);

            // Suppress the onbeforeunload event first. This prevents the application hanging on a dialog box that does not close.
            ((IJavaScriptExecutor)driver).ExecuteScript("window.onbeforeunload = function(e){};");
            return driver;
        }
    }
}
